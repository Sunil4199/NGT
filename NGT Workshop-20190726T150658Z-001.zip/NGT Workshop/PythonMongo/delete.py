from pymongo import MongoClient
client = MongoClient('localhost:27017')
db = client.EmployeeData
def delete():
    try:
        criteria = input("\nEnter employee name to delete\n")
        db.Employees.delete_many({"name":criteria})
        print("\nDeletion successful\n") 
    except (Exception):
        print(str(e))


delete()
